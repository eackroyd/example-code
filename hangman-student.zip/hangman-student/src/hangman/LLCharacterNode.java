package hangman;


public class LLCharacterNode{
	private char info;
	private LLCharacterNode link;
	
	public LLCharacterNode(char infor){
		info = infor;
		link = null;
	}
	
	public void setInfo(char infor){
		info = infor;
	}
	
	public char getInfo(){
		return info;
	}
	
	public void setLink(LLCharacterNode link){
		this.link = link;
	}
	
	public LLCharacterNode getLink(){
		return link;
	}
}