package hangman;

/**
 * The Array implementation of the GameModel interface.
 */
public class ArrayGameModel implements GameModel {
	/** The number of characters (lower/upper). */
	private static final int ALPHABET_COUNT = 26*2;
	
	/** hung state */
	private int state;
	String secretWord;
	String guessWord;
	int guessCount;
	char[] guesses = new char[ALPHABET_COUNT];
	char[] correct;
	
	/**
	 * Creates a new ArrayGameModel object.
	 * 
	 *  guessWord the word to guess
	 */
	public ArrayGameModel(String guessWord) {
		// TODO (1)
		state = STARTING_STATE;
		secretWord = guessWord;
		correct = new char[secretWord.length()];
	}
		
	public boolean isPriorGuess(char guess) {
		boolean priorG = false;
		for(int i = 0; i < guesses.length; i++){
			if(guess == guesses[i]){
				priorG = true;
			}
		}
		return priorG;
	}
	
	public int numberOfGuesses() {
		// TODO (3)
		return guessCount;
	}
	
	public boolean isCorrectGuess(char guess) {
		boolean crt = false;
		for(int i = 0; i < secretWord.length(); i++){
			if((guess == secretWord.charAt(i)) && (this.isPriorGuess(guess) == false)){
				crt = true;
			}
		}
		return crt;
	}
	
	public boolean doMove(char guess) {
		
		boolean isTrue = false;
			if(!this.isPriorGuess(guess)){	
				guesses[guessCount] = guess;
				guessCount++;
				
				
				for(int i = 0; i < secretWord.length(); i++){
					
					if(guess == secretWord.charAt(i)){
						correct[i] = guess;
						isTrue = true;
					}
					
					
				}
				if(isTrue == false)state++;
				
			}
		 return isTrue;
			
		}

	public boolean inWinningState() {
		boolean wng = true;
		
		for(int i = 0; i < correct.length; i++){
			if(correct[i] == '\u0000'){
				wng = false;
			}
		}
		
		return wng;
	}

	public boolean inLosingState() {
		boolean losing = false;
		
		if(state == 10){
			losing = true;
		}
		return losing;
	}
	
	public String toString() {
		String b = "";
		
		for(int i = 0; i < correct.length ; i++){
			if(correct[i] != '\u0000'){
				b+= correct[i] + " ";
			}
			else
				b+="_ ";
			
		}
		
		b=b.trim();
		return b;
	}

	public String previousGuessString() {
		String s = "";
		int i = 0;
		while(guesses[i] != '\u0000'){
			s+= ", " + guesses[i];
			i++;
		}
		s=s.substring(1, s.length());
		s = s.trim();
		return "[" + s + "]";
	}
	
	public int getState() {
		return state;
	}

	public String getWord() {
		return secretWord;
	}
  
}
