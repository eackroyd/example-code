package hangman;

public final class LinkedListGameModel implements GameModel {
	char guess;
	String secretWord;
	private int state;
	int guessCount;
	LLCharacterNode head;
	LLCharacterNode head2;
	
	
	
	public LinkedListGameModel(String secretWrd){
		secretWord = secretWrd;
		state = STARTING_STATE;
		guessCount = 0;
	}
	
	@Override
	public boolean isPriorGuess(char guess) {
		boolean prior = false;
		LLCharacterNode currNode = head;
		while(currNode != null){
			if(guess == currNode.getInfo()){
				prior = true;
			}
			currNode = currNode.getLink();
		}
		
		return prior;
	}

	
	public int numberOfGuesses() {
		return guessCount;
	}

	public boolean isCorrectGuess(char guess) {
		boolean isCorrect = false;
		for(int i = 0; i < secretWord.length(); i++){
			if(secretWord.charAt(i) == guess){
				isCorrect = true;
			}
			
		}
		return isCorrect;
	}

	@Override
	public boolean doMove(char guess) {
		boolean isTrue = false;
		if(!this.isPriorGuess(guess)){	
			
			LLCharacterNode node = new LLCharacterNode(guess);
			node.setLink(head);
			head = node;
			
			guessCount++;
			
			
			for(int i = 0; i < secretWord.length(); i++){
				if(guess == secretWord.charAt(i)){
					LLCharacterNode newNode = new LLCharacterNode(guess);
					newNode.setLink(head2);
					head2 = newNode;
					isTrue = true;
				}
				
				
			}
			if(isTrue == false)state++;
			
		}
	 return isTrue;
		
	}

	@Override
	public boolean inWinningState() {
		
		boolean wng = true;
		int nodeCount = 0;
		LLCharacterNode currNode = head2;
		while(currNode != null){
			nodeCount++;
			currNode = currNode.getLink();
		}
		if(nodeCount < secretWord.length()){
			wng = false;
		}
		return wng;
	}

	@Override
	public boolean inLosingState() {
		boolean ste = false;
		
		if(state == 10){
			ste = true;
		}
		return ste;
	}

	@Override
	public int getState() {
		return state;
	}
	
	public String toString(){
		String b = "";
		boolean isThere;
		for(int i = 0; i < secretWord.length(); i++){
			LLCharacterNode currNode = head;
			isThere = false;
			while(currNode != null){
				if(currNode.getInfo() == secretWord.charAt(i)){
					b+= secretWord.charAt(i) + " ";
					isThere = true;
				}
				currNode = currNode.getLink();
			}
			if(!isThere){	
				b+="_ ";
			}
			
			
		}	
		
		b=b.trim();
		return b;
	}

	@Override
	public String previousGuessString() {
		
		String s = "";
		String b = "";
		LLCharacterNode currNode = head;
		while(currNode != null){
			s += " ," + currNode.getInfo();
			currNode = currNode.getLink();
		}
		s=s.substring(1, s.length());
		s = s.trim();
		
		
		for(int i = s.length() - 1; i >= 0; i--){
			b+= s.charAt(i);
		}
		
		b = b.substring(0,b.length()-1);
		return "[" + b + "]";
	}

	@Override
	public String getWord() {
		return secretWord;
	}

}
