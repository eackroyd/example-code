package structures;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class BinarySearchTree<T extends Comparable<T>> implements
		BSTInterface<T> {
	protected BSTNode<T> root;

	public boolean isEmpty() {
		return root == null;
	}

	public int size() {
		return subtreeSize(root);
	}

	public int subtreeSize(BSTNode<T> node) {
		if (node == null) {
			return 0;
		} else {
			return 1 + subtreeSize(node.getLeft())
					+ subtreeSize(node.getRight());
		}
	}
	
	public BinarySearchTree<T> getSubtree(BSTNode<T> node){
		BinarySearchTree<T> newTree = new BinarySearchTree<T>();
		newTree.setRoot(node);
		return newTree;
	}

	public boolean contains(T t) {
		// TODO
		
		if(t == null){
			throw new NullPointerException();
		}
		
		BSTNode<T> node = getHelper(root, t);
		if(node == null){
			return false;
		}
		else if(node.getData().compareTo(t) == 0){
			return true;
		}
		else 
			return false;
	}

	public boolean remove(T t) {
		
		if(t == null){
			throw new NullPointerException();
		}
		
		boolean result = contains(t);
		if (result) {
			root = removeFromSubtree(root, t);
		}
		return result;
	}

	private BSTNode<T> removeFromSubtree(BSTNode<T> node, T t) {
		// node must not be null
		if(node == null || t == null){
			throw new NullPointerException();
		}
		int result = t.compareTo(node.getData());
		if (result < 0) {
			node.setLeft(removeFromSubtree(node.getLeft(), t));
			return node;
		} else if (result > 0) {
			node.setRight(removeFromSubtree(node.getRight(), t));
			return node;
		} else { // result == 0
			if (node.getLeft() == null) {
				return node.getRight();
			} else if (node.getRight() == null) {
				return node.getLeft();
			} else { // neither child is null
				T predecessorValue = getHighestValue(node.getLeft());
				node.setLeft(removeRightmost(node.getLeft()));
				node.setData(predecessorValue);
				return node;
			}
		}
	}

	private T getHighestValue(BSTNode<T> node) {
		// node must not be null
		if(node == null){
			throw new NullPointerException();
		}
		if (node.getRight() == null) {
			return node.getData();
		} else {
			return getHighestValue(node.getRight());
		}
	}

	private BSTNode<T> removeRightmost(BSTNode<T> node) {
		// node must not be null
		if (node.getRight() == null) {
			return node.getLeft();
		} else {
			node.setRight(removeRightmost(node.getRight()));
			return node;
		}
	}

	public T get(T t) {
		// TODO
		if(t == null){
			throw new NullPointerException();
		}
		
		BSTNode<T> node = getHelper(root, t);
		if(node == null){
			return null;
		}
		else if(node.getData().compareTo(t) == 0){
			return node.getData();
		}
		else 
			return null;
	}
	
	public BSTNode<T> getHelper(BSTNode<T> node, T t){
		if(node == null){
			return node;
		}
		else if(t.compareTo(node.getData()) < 0){
			return getHelper(node.getLeft(), t);
		}
		else if(t.compareTo(node.getData()) > 0){
			return getHelper(node.getRight(), t);
		}
		else
			return node;
	}

	public void add(T t) {
		root = addToSubtree(t, root);
	}
	
	public BSTNode<T> addToSubtree(T t, BSTNode<T> node) {
		if (node == null) {
			return new BSTNode<T>(t, null, null);
		}
		if (t.compareTo(node.getData()) <= 0) {
			node.setLeft(addToSubtree(t, node.getLeft()));
		} else {
			node.setRight(addToSubtree(t, node.getRight()));
		}
		return node;
	}

	@Override
	public T getMinimum() {
		// TODO
		return getMinimumHelper(root);
	}
	
	public T getMinimumHelper(BSTNode<T> node){
		if(node == null){
			return null;
		}
		if (node.getLeft() == null) {
			return node.getData();
		} else {
			return getMinimumHelper(node.getLeft());
		}
	}
	
	@Override
	public T getMaximum() {
		// TODO
		return getHighestValue(root);
	}

	@Override
	public int height() {
		// TODO
		if(size() == 0){
			return -1;
		}	
		else 
			return heightHelper(root);
	}
	
	public int heightHelper(BSTNode<T> node){

		if(node == null){
			return -1;
		}
		
		int leftHeight = heightHelper(node.getLeft());
		int rightHeight = heightHelper(node.getRight());
		
		return 1 + Math.max(leftHeight, rightHeight);
		
	}
	
	
	
	@Override
	public Iterator<T> preorderIterator() {
		// TODO
		Queue<T> queue = new LinkedList<T>();
		preOrderTraverse(queue, root);
		return queue.iterator();
	}
	
	public void preOrderTraverse(Queue<T> queue, BSTNode<T> node){
		if(node != null){
			queue.add(node.getData());
			preOrderTraverse(queue, node.getLeft());
			preOrderTraverse(queue, node.getRight());
		}
	}
	
	

	@Override
	public Iterator<T> inorderIterator() {
		Queue<T> queue = new LinkedList<T>();
		inorderTraverse(queue, root);
		return queue.iterator();
	}
	
	public void inorderTraverse(Queue<T> queue, BSTNode<T> node) {
		if (node != null) {
			inorderTraverse(queue, node.getLeft());
			queue.add(node.getData());
			inorderTraverse(queue, node.getRight());
		}
	}
	
	public LinkedList<T> inOrderTrav(LinkedList<T> list, BSTNode<T> node){
		if (node != null) {
			inorderTraverse(list, node.getLeft());
			list.add(node.getData());
			inorderTraverse(list, node.getRight());
		}
		return list;
	}

	@Override
	public Iterator<T> postorderIterator() {
		// TODO
		Queue<T> queue = new LinkedList<T>();
		postOrderTraverse(queue, root);
		return queue.iterator();
	}
	
	public void postOrderTraverse(Queue<T> queue, BSTNode<T> node){
		if(node!=null){
			postOrderTraverse(queue,node.getLeft());
			postOrderTraverse(queue, node.getRight());
			queue.add(node.getData());
		}
	}

	@Override
	public boolean equals(BSTInterface<T> other) {
		// TODO
		if(other == null){
			throw new NullPointerException();
		}
		
		boolean eq = false;
		Iterator<T> iter = this.inorderIterator();
		Iterator<T> itr = other.inorderIterator();
		T[] ths = (T[]) new Comparable[this.size()];
		T[] oth = (T[]) new Comparable[other.size()];
		for(int i = 0; i < this.size(); i++){
			ths[i] = iter.next();
		}
		for(int i = 0; i < other.size(); i++){
			oth[i] = itr.next();
		}
		if(other.size() == this.size()){
			for(int i = 0; i < this.size(); i++){
				if(ths[i].compareTo(oth[i]) == 0){
					eq = true;
				}
				else 
					eq = false;
			}
		}
		return eq;
	}

	@Override
	public boolean sameValues(BSTInterface<T> other) {
		// TODO
		if(other == null){
			throw new NullPointerException();
		}
		
		if(other.isEmpty() && this.isEmpty()){
			return true;
		}
		
		Iterator<T> itr = this.inorderIterator();
		Iterator<T> iter = other.inorderIterator();
		boolean cont = false;
		for(int i = 0; i < this.size(); i++){
			if(this.contains((T)iter.next())){
				cont = true;
			}
			else 
				cont = false;
		}		
		
		return cont;
	}

	@Override
	public boolean isBalanced() {
		// TODO
		if(size() == 0){
			return true;
		}
		int right = heightHelper(root.getRight());
		int left = heightHelper(root.getLeft());
		if(Math.abs(right - left) <= 1){
			return true;
		}
		else{ 
			return false;
		}	
	}

	@Override
	public void balance() {
		// TODO	
		
		if(size() == 0){
			return;
		}
		
		T[] nodes = (T[]) new Comparable[size()];
		Iterator itr = this.inorderIterator();
		
		for(int i = 0; i < size(); i++){
			T temp = (T) itr.next();
			nodes[i] = temp;
			this.remove(temp);
		}
		
		balanceHelper(nodes, 0, size() - 1);
		
	}
	
	public void rebuildAt(BSTNode<T> node){
		if(node == null){
			this.balance();
		}
		int subSize = this.subtreeSize(node);
		T[] nodes = (T[]) new Comparable[subSize];
		Iterator<T> itr = this.inorderIterator();
		
		
		for(int i = 0; i < this.size(); i++){
			int index = 0;
			T temp = itr.next();
			if(temp.compareTo(node.getData()) >= 0){
				nodes[index] = temp;
				index++;
			}
		}
		
		balanceHelper(nodes, 0, subSize);
	}
	
	
	public void balanceHelper(T[] nodes, int low, int high){
		BinarySearchTree<T> tree = new BinarySearchTree<T>();
		int mid = (low + high) /2;
		if (low == high){
			tree.add(nodes[low]);
		}
		else if ((low + 1) == high){
			tree.add(nodes[low]);
			tree.add(nodes[high]);
		}
		else{
			tree.add(nodes[mid]);
			balanceHelper(nodes,low, mid - 1); 
			balanceHelper(nodes, mid + 1, high);
		}
	}

	@Override
	public BSTNode<T> getRoot() {
		// DO NOT MODIFY
		return root;
	}
	public void setRoot(BSTNode<T> node){
		this.root = node;
	}

	public static <T extends Comparable<T>> String toDotFormat(BSTNode<T> root) {
		// DO NOT MODIFY
		// see project description for explanation

		// header
		int count = 0;
		String dot = "digraph G { \n";
		dot += "graph [ordering=\"out\"]; \n";
		// iterative traversal
		Queue<BSTNode<T>> queue = new LinkedList<BSTNode<T>>();
		queue.add(root);
		BSTNode<T> cursor;
		while (!queue.isEmpty()) {
			cursor = queue.remove();
			if (cursor.getLeft() != null) {
				// add edge from cursor to left child
				dot += cursor.getData().toString() + " -> "
						+ cursor.getLeft().getData().toString() + ";\n";
				queue.add(cursor.getLeft());
			} else {
				// add dummy node
				dot += "node" + count + " [shape=point];\n";
				dot += cursor.getData().toString() + " -> " + "node" + count
						+ ";\n";
				count++;
			}
			if (cursor.getRight() != null) {
				// add edge from cursor to right child
				dot += cursor.getData().toString() + " -> "
						+ cursor.getRight().getData().toString() + ";\n";
				queue.add(cursor.getRight());
			} else {
				// add dummy node
				dot += "node" + count + " [shape=point];\n";
				dot += cursor.getData().toString() + " -> " + "node" + count
						+ ";\n";
				count++;
			}

		}
		dot += "};";
		return dot;
	}
}