package hanoi;

import structures.LinkedStack;

/**
 * A {@link StackBasedHanoiPeg} is an implementation of {@link HanoiPeg}.
 * 
 * @author jcollard
 * @param <T>
 */
public class StackBasedHanoiPeg<T> implements HanoiPeg {
	
	int n;
	
	private LinkedStack<HanoiRing> stack;
	
	/**
	 * Creates a new {@link StackBasedHanoiPeg} that has no rings.
	 */
	public StackBasedHanoiPeg() {
		stack = new LinkedStack<HanoiRing>();
		n = 0;
	}

	@Override
	public void addRing(HanoiRing ring) throws IllegalHanoiMoveException {
		if(ring == null){
			throw new NullPointerException();
		}
		if(!stack.isEmpty()){
			if(ring.getSize() >= stack.peek().getSize()){
				throw new IllegalHanoiMoveException("Cannot put bigger ring on a smaller ring");
			}
		}	
		stack.push(ring);
		n++;
	}

	@Override
	public HanoiRing remove() throws IllegalHanoiMoveException {
		if(!stack.isEmpty())	
			return stack.pop();
		else 
			throw new IllegalHanoiMoveException("Cannot remove ring from empty peg");
	}

	@Override
	public HanoiRing getTopRing() throws IllegalHanoiMoveException {
		if(!stack.isEmpty())	
			return stack.peek();
		else 
			throw new IllegalHanoiMoveException("Cannot access a ring from empty peg");
	}

	@Override
	public boolean hasRings() {
		return(!stack.isEmpty());
	}
}
