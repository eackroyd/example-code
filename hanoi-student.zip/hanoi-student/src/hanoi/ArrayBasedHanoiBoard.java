package hanoi;

/**
 * A {@link ArrayBasedHanoiBoard} is a simple implementation of
 * {@link HanoiBoard}
 * 
 * @author jcollard
 * 
 */
public class ArrayBasedHanoiBoard implements HanoiBoard {
	
	StackBasedHanoiPeg[] board;
	StackBasedHanoiPeg peg0;
	StackBasedHanoiPeg peg1;
	StackBasedHanoiPeg peg2;
	int rings;
	
	/**
	 * Creates a {@link ArrayBasedHanoiBoard} with three empty {@link HanoiPeg}s
	 * and {@code n} rings on peg 0.
	 */
	public ArrayBasedHanoiBoard(int n) throws IllegalArgumentException {
		if(n < 0){
			throw new IllegalArgumentException();
		}
		rings = n;
		board = new StackBasedHanoiPeg[3];
		peg0 = new StackBasedHanoiPeg();
		peg1 = new StackBasedHanoiPeg();
		peg2 = new StackBasedHanoiPeg();
		board[0] = peg0;
		board[1] = peg1;
		board[2] = peg2;
		for(int i = rings; i > 0; i--){
			HanoiRing ring = new HanoiRing(i);
			board[0].addRing(ring);
		}
	}

	@Override
	public void doMove(HanoiMove move) throws IllegalHanoiMoveException, NullPointerException {
		
		int from = move.getFromPeg();
		int to = move.getToPeg();
		
		if (!isLegalMove(move)) {
			throw new IllegalHanoiMoveException(
					"Could not perform illegal move.");
		}
		
		if(board[from] == null){
			throw new NullPointerException();
		}
		
		board[to].addRing(board[from].remove());
			
	}

	@Override
	public boolean isSolved() {
		if(!board[0].hasRings() && !board[1].hasRings()){
			return true;
		}
		
		return false;
	}

	@Override
	public boolean isLegalMove(HanoiMove move) throws NullPointerException {
		int from  = move.getFromPeg();
		int to = move.getToPeg();
		
		if(move == null){
			throw new NullPointerException();
		}
		
		if(from < 0 || to > 3){
			return false;
		}
		if(from == to){
			return false;
		}
		
		if(board[to] == null){
			return false;
		}
		
		if(!board[from].hasRings()){
			return false;
		}
		
		if(board[from].hasRings() && board[to].hasRings()){
			if(board[from].getTopRing().getSize() > board[to].getTopRing().getSize()){
				return false;
			}
		}	
		
		return true;
		
	}
}
