package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

class LinkedNodeIterator<T> implements Iterator<T> {
	Node<T> head;

  // Constructors
  public LinkedNodeIterator(Node<T> head) {
	  this.head = head;
  }

  @Override
  public boolean hasNext() {
	if(head!=null){
		return
			true;
	}
	else
		return false;
  }

  @Override
  public T next() {
	if(head!=null){  
		if(this.hasNext()){
			T nwData = head.getData();
			head = head.getNext();
			return nwData;
		}
		else
			throw new NoSuchElementException();
		}
	else
		throw new NoSuchElementException();
  }

  // Leave this one alone.
  @Override
  public void remove() {
    throw new UnsupportedOperationException();
  }
}
