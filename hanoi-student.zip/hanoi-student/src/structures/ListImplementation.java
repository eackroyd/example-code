package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.Iterable;
import structures.LinkedNodeIterator;

public class ListImplementation<T> implements ListInterface<T> {
	
	int size;
	Node<T> head;
	Node<T> tail;
	
	public ListImplementation(){
		size = 0;
		head = null;
		tail = null;
	}
	
	
	
	public int size(){
		return size;
	}
	
	public boolean isEmpty(){
		return (head == null);
	}
	
	public T get(int n) throws NoSuchElementException{
		if(n >= size || n < 0){
			throw new NoSuchElementException();
		}
		if(n == 0){
			return head.getData();
		}
		Iterator<T> itr = this.iterator();
		int i = 0;
		T info = null;
		while(i <= n){
			info = itr.next();
			i++;
		}
		return info;
	}
	
	public ListInterface<T> append(T elem) throws NullPointerException{
		if(elem == null){
			throw new NullPointerException();
		}
		
		Node<T> newNode = new Node<T>(elem, null);
		 if (tail == null)
			 head = newNode;
		 else
			 tail.setNext(newNode);
		 tail = newNode;
		
		size++;
		
		return this;
	}
	
	public Iterator<T> iterator(){
		return new LinkedNodeIterator<T>(head);
	}
	
	
}