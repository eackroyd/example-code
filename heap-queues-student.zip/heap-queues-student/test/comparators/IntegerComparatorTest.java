package comparators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class IntegerComparatorTest {

  IntegerComparator comparator;
  ReverseIntegerComparator comp;
	
  @Before
  public void setup() {
    comparator = new IntegerComparator();
    comp = new ReverseIntegerComparator();
  }

  @Test (timeout = 100)
  public void testOne() {
	  assertEquals("Should be 1", 1, comparator.compare(6, 3));
	  assertEquals("Should be -1", -1, comparator.compare(2, 9));
	  assertEquals("Should be -1", -1, comp.compare(5, 2));
	  assertEquals("Should be 0", 0, comp.compare(2, 2));
  }

}
