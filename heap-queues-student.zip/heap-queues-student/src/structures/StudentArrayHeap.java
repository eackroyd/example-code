package structures;

import java.util.Comparator;

public class StudentArrayHeap<P, V> extends AbstractArrayHeap<P, V> {
	int rightChild = 0;
	int leftChild = 0;
	int big = 0;
	
	protected StudentArrayHeap(Comparator<P> comparator) {
		super(comparator);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected int getLeftChildOf(int index) {
		// TODO Auto-generated method stub
		if(index < 0){
			throw new IndexOutOfBoundsException();
		}
		return ((2*index) + 1);
	}

	@Override
	protected int getRightChildOf(int index) {
		// TODO Auto-generated method stub
		if(index < 0){
			throw new IndexOutOfBoundsException();
		}
		
		return ((2*index) + 2);
	}

	@Override
	protected int getParentOf(int index) {
		// TODO Auto-generated method stub
		if(index < 0){
			throw new IndexOutOfBoundsException();
		}
		if(((index - 1) / 2.0) < 0){
			throw new IndexOutOfBoundsException();
		}
		return ((index - 1) / 2);
	}

	@Override
	protected void bubbleUp(int index) {
		// TODO Auto-generated method stub
		int start = index;
		int parnt = ((index - 1) /2);
		Entry<P,V> hole = heap.get(index);
		Entry<P,V> parent = heap.get(parnt);
		while(index > 0 && comparator.compare(hole.getPriority(),(parent.getPriority())) > 0){
			heap.set(start, parent);
			start = parnt;
			parnt = ((start- 1)/2); 
			heap.set(start, hole);
			hole = heap.get(start);
			parent = heap.get(parnt);
		}
		
		heap.set(start, hole);
	}

	@Override
	protected void bubbleDown(int index) {
		// TODO Auto-generated method stub
		
		bubbleDownHelper(index, heap.size() - 1);
		
	}
	
	protected void bubbleDownHelper(int start, int end) {
		if(start == end){
			return;
		}
		else{
			leftChild = start *2 +1;
			
			if(leftChild <= end){
				rightChild = leftChild + 1;
				big = leftChild;
				
				if(rightChild <= end && comparator.compare(heap.get(leftChild).getPriority(), heap.get(rightChild).getPriority()) < 0){
					big = rightChild;
				}
				
				if(comparator.compare(heap.get(start).getPriority(), heap.get(big).getPriority()) < 0){
					super.swap(big, start);
					bubbleDownHelper(big, end);
				}
			}
			
		}
	}
	
	
	
}
