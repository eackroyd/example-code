package structures;

import java.util.Iterator;
import java.util.LinkedList;
import java.lang.Math;

public class ScapegoatTree<T extends Comparable<T>> extends
		BinarySearchTree<T> {

	private int upperBound;
	
	
	/**
	 * Adds an element to the tree.
	 * 
	 * The modified tree must still obey the BST rule, though it might not be
	 * balanced.
	 * 
	 * In addition to obeying the BST rule, the resulting tree must also obey
	 * the scapegoat rule. 
	 * 
	 * This method must only perform rebalancing of subtrees when indicated
	 * by the scapegoat rule; do not unconditionally call balance() 
	 * after adding, or you will receive no credit. 
	 * See the project writeup for details.
	 * 
	 * @param element
	 * @throws NullPointerException if element is null
	 */
	@Override
	public void add(T element) {
		// TODO	
		
		if(element == null){
			throw new NullPointerException();
		}
		
		upperBound++;
		BSTNode<T> u = new BSTNode<T>(element, null, null);     
		root = addToSubtree(element, root);
		int d = height();
		if(d > (Math.log10(upperBound))/(Math.log10(1.5))){
			BSTNode<T> w = this.getHelper(root, element);
			if(w.equals(root)){
				return;
			}
			while((1.0 * (this.subtreeSize(w) / this.subtreeSize(w.getParent()))) < 2/3){
				w = w.getParent();
			}
			rebuildAt(w.getParent());
		}
		
	}
	
	public int addHelper(BSTNode<T> u){
		BSTNode<T> w = root;
        if (w == null) {
            root = u;
            return 0;
        }
        boolean done = false;
        int d = 0;
        while (!done) {
            if (u.getData().compareTo(w.getData()) < 0) {
                if (w.getLeft() == null) {
                    w.setLeft(u);
                    done = true;
                } 
                else {
                    w = w.getLeft();
                }
            } 
            else if (u.getData().compareTo(w.getData()) > 0) {
                if (w.getRight() == null){
                    w.setRight(u);
                   
                    done = true;
                }
                w = w.getRight();
            } 
            else{
                return -1;
            }
            d++;
        } 
        
        return d;

	}
	
	/**
	 * Attempts to remove one copy of an element from the tree, returning true
	 * if and only if such a copy was found and removed.
	 * 
	 * The modified tree must still obey the BST rule, though it might not be
	 * balanced.
	 * 
	 * In addition to obeying the BST rule, the resulting tree must also obey
	 * the scapegoat rule.
	 * 
	 * This method must only perform rebalancing of subtrees when indicated
	 * by the scapegoat rule; do not unconditionally call balance() 
	 * after removing, or you will receive no credit. 
	 * See the project writeup for details.

	 * @param element
	 * @return true if and only if an element removed
	 * @throws NullPointerException if element is null
	 */
	@Override
	public boolean remove(T element) {
		// TODO
		if(element == null){
			throw new NullPointerException();
		}
		
		upperBound--;
		
		boolean result = contains(element);
		if (result) {
			root = removeFromSubtree(root, element);
		}
		if(upperBound / 2.0 > this.size() || this.size() > upperBound){
			rebuildAt(root);
		}
		return result;
		
	}

}
